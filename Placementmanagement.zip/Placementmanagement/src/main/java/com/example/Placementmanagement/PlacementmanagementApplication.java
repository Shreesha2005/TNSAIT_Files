package com.example.Placementmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementmanagementApplication.class, args);
	}

}
